/// Proje genelinde kullanılacak sabit ayarlar
class AppConfig {
  /// Türkçe karakter ve boşluk içermeyen kullanıcı adı
  static const String currentUser = 'ahmet_tayfur';
}
