import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';

final PersistentTabController navController = PersistentTabController(
  initialIndex: 0,
);
